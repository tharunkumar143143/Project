import React, {
    useState
} from "react";

function App() {
    const [countries, setCountries] = useState([]);

    const addCountry = () => {
        const countryName = prompt("Enter country name:");
        if (countryName) {
            setCountries([...countries, {
                name: countryName,
                states: []
            }]);
        }
    };

    const editCountry = (index) => {
        const newName = prompt("Edit country name:", countries[index].name);
        if (newName && window.confirm("Are you sure you want to update this country?")) {
            const updatedCountries = [...countries];
            updatedCountries[index].name = newName;
            setCountries(updatedCountries);
        }
    };

    const deleteCountry = (index) => {
        if (window.confirm("Are you sure you want to delete this country? This will remove all states and cities.")) {
            setCountries(countries.filter((_, i) => i !== index));
        }
    };

    const addState = (countryIndex) => {
        const stateName = prompt("Enter state name:");
        if (stateName) {
            const updatedCountries = [...countries];
            updatedCountries[countryIndex].states.push({
                name: stateName,
                cities: []
            });
            setCountries(updatedCountries);
        }
    };

    const deleteState = (countryIndex, stateIndex) => {
        if (window.confirm("Are you sure you want to delete this state? This will remove all associated cities.")) {
            const updatedCountries = [...countries];
            updatedCountries[countryIndex].states.splice(stateIndex, 1);
            setCountries(updatedCountries);
        }
    };

    const addCity = (countryIndex, stateIndex) => {
        const cityName = prompt("Enter city name:");
        if (cityName) {
            const updatedCountries = [...countries];
            updatedCountries[countryIndex].states[stateIndex].cities.push(cityName);
            setCountries(updatedCountries);
        }
    };

    const deleteCity = (countryIndex, stateIndex, cityIndex) => {
        if (window.confirm("Are you sure you want to delete this city?")) {
            const updatedCountries = [...countries];
            updatedCountries[countryIndex].states[stateIndex].cities.splice(cityIndex, 1);
            setCountries(updatedCountries);
        }
    };

    return ( <
        div >
        <
        h1 > Country, State, and City Management < /h1> <
        button onClick = {
            addCountry
        } > Add Country < /button> <
        ul > {
            countries.map((country, countryIndex) => ( <
                li key = {
                    countryIndex
                } > {
                    country.name
                } <
                button onClick = {
                    () => editCountry(countryIndex)
                } > Edit < /button> <
                button onClick = {
                    () => deleteCountry(countryIndex)
                } > Delete < /button> <
                button onClick = {
                    () => addState(countryIndex)
                } > Add State < /button> <
                ul > {
                    country.states.map((state, stateIndex) => ( <
                        li key = {
                            stateIndex
                        } > {
                            state.name
                        } <
                        button onClick = {
                            () => deleteState(countryIndex, stateIndex)
                        } > Delete < /button> <
                        button onClick = {
                            () => addCity(countryIndex, stateIndex)
                        } > Add City < /button> <
                        ul > {
                            state.cities.map((city, cityIndex) => ( <
                                li key = {
                                    cityIndex
                                } > {
                                    city
                                } <
                                button onClick = {
                                    () => deleteCity(countryIndex, stateIndex, cityIndex)
                                } > Delete < /button> < /
                                li >
                            ))
                        } <
                        /ul> < /
                        li >
                    ))
                } <
                /ul> < /
                li >
            ))
        } <
        /ul> < /
        div >
    );
}

export default App;